{
 "cells": [
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "# <b>Open Chat</b>\n",
    "___"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "This repository contains the showcase project developed in the Secure and Private AI Scholarship. For more details, please visit this site\n",
    "\n",
    "Author: Biswajit Banerjee <br>\n",
    "Email  : sumonbanner@gmail.com <br>\n",
    "Slack  : @Biswajit Banerjee  <br>"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "## Introduction\n",
    "---"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "This is a messaging application built totally from scratch, where users from multiple locations in the globe can join and chat with each other. The special factor in this application is, it translates the message from sending user to the receiving user's choice.<br>\n",
    "Let's say, a user Bob from London is chatting with another user Julia from Germany. Bob prefers to chat in English and Julia prefers to chat in German. So when both of the logs into this application and chats with each other <br>Bob's `English messages will be translated to German` and will be sent to Julia and Julia's `German messages will be translated to English` and will be sent to Bob.<br>\n",
    "Currently it supports English (en) and German (de) only, but there is a lot of room for adding other languages."
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "## Definitions\n",
    "___"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "<b>Neural Machine Translation (NMT) </b>: *Neural Machine Translation (NMT) is an end-to-end learning approach for automated translation, with the potential to overcome many of the weaknesses of conventional phrase-based translation systems*. <br>\n",
    ">\"In a machine translation task, the input already consists of a sequence of symbols in some language, and the computer program must convert this into a sequence of symbols in another language\"\n",
    "— Page 98, Deep Learning, 2016. \n",
    "<br>"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "<b>Socket</b>: *A socket is one endpoint of a two-way communication link between two programs running on the network*.\n",
    "> In simpler terms, a socket is a network object the helps sending and reciving message over the internet"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "## Requirements\n",
    "---"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "* Python 3.7 or above\n",
    "* PyTorch 1.1.0 or above\n",
    "* PySyft 0.1 or above\n",
    "* Matplotlib 3.0 or above (optional)"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "## Running\n",
    "---"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "This program allows you to send messages directly from your command line to the internet and connect to a server located anywhere.<br>\n",
    "Fisrt we will need to start the server<br>\n",
    "```bash\n",
    "python3 server.py -host 127.0.0.1 -port 1234\n",
    "```\n",
    "Then once the server is up and running the users will be abele to join<br>\n",
    "```bash\n",
    "python3 client.py -host 127.0.0.1 -port 1234\n",
    "```"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "## Results\n",
    "---"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "First the Seq2Seq machine translation results<br>\n",
    "```\n",
    "Input :  Wir sind noch nicht ganz fertig.\n",
    "Target:  we re not totally ready yet.\n",
    "Output:  we re not all finished yet.\n",
    "```\n",
    "```\n",
    "Input :  Ich bin sonntags nicht zu hause.\n",
    "Target:  i m not home on sundays.\n",
    "Output:  i m not home on sundays.\n",
    "```\n",
    "```\n",
    "Input :  Ich lerne maschineschreiben.\n",
    "Target:  i m learning how to type.\n",
    "Output:  i m studying how to type.\n",
    "```\n",
    "```\n",
    "Input :  Ich bin nicht mehr hungrig.\n",
    "Target:  i m not hungry anymore.\n",
    "Output:  i m not hungry anymore.\n",
    "```\n",
    "```\n",
    "Input :  Ich uberfliege gerade seinen bericht.\n",
    "Target:  i m skimming his report right now.\n",
    "Output:  i m skimming his report right now.\n",
    "```\n",
    "```\n",
    "Input :  Ich bin froh , bei dir zu sein.\n",
    "Target:  i am glad to be with you.\n",
    "Output:  i am glad i am with you.\n",
    "\n",
    "```"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "Some visuals of the entire users and server <br>\n",
    "[Example](./files/example2.png?raw=true 'Title)"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "## Conclusions\n",
    "---"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "This application is primarily based on network communications and message translations. It also has a lot of space to add as many languages as we can which in future will become a big application. As the sockets are very efficient multiple language translations will just add very little impact to this application.<br> \n",
    "It uses PyTorch for translations which I learnt from this course and sockets which I also learnt from this course.\n",
    "I am very much thankful to Udacity for providing such a huge platform and Facebook for providing the scholarship.<br>\n",
    "This project will not be possible without Andrew Trask's guidance in this course and Palak Sadani & Akshit Jain, both of their constant help and supervision, Thanks a lot.<br>\n",
    "Last but not least the Secure and Private AI slack community always ready to help, thank all of you."
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    " "
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    " "
   ]
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.7.1"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 2
}
